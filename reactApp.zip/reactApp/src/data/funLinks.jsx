const funLinks = [
    { name: 'Cool Math Games', link: 'https://www.coolmathgames.com',description: '' },
    { name: 'The Useless Web', link: 'https://www.theuselessweb.com',description: '' },
    { name: 'Staggering Beauty', link: 'https://www.staggeringbeauty.com',description: '' },
    { name: 'Window Swap', link: 'https://www.window-swap.com/',description: '' },
    { name: 'Bored Button', link: 'https://www.boredbutton.com/',description: '' },
  ];
  
  export default funLinks;